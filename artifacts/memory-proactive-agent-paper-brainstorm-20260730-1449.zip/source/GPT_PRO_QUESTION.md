You are GPT Pro acting as a skeptical research advisor and top-conference reviewer.

I am not asking you to write code. I want you to evaluate and sharpen a research idea. Treat the attached evidence as partial evidence. Do not invent citations as facts; if you mention likely related-work clusters, mark them as clusters unless exact papers are supplied.

Idea / project:

Memory as Active Constraint State for Calibrated Proactive Agents.

The proposed system incrementally converts cross-session interactions into a provenance-aware, time-aware, versioned constraint state covering user goals, preferences, commitments, cancellations, permissions, failure modes, and unresolved dependencies. A proactive policy uses this state to choose among silence, ask, suggest, prepare, and execute under asymmetric benefit, interruption, false-positive, privacy, permission, and compute costs.

The intended empirical claim is that explicit online constraint lifecycle management plus a memory-conditioned intervention gate improves hidden-intent resolution and task completeness while reducing false alarms, stale-memory activations, cancellation errors, and permission violations.

Candidate evaluation:

- π-Bench for hidden intents, cross-session continuity, Proactivity and Completeness;
- LoCoMo-Plus for latent constraint consistency;
- ProEvent for event modification/cancellation and overaction;
- MemoryArena for memory-guided action;
- ProactiveBench for false-alarm and intervention calibration.

Potential method components:

1. Online constraint writer with no access to future evaluation questions.
2. State schema: subject, predicate, scope, valid interval, status, confidence, provenance, supersedes, allowed actions.
3. Conflict/update/expiry/deletion transitions.
4. Retrieval of active constraints plus evidence.
5. Benefit–burden gate and action-level permission policy.
6. Optional proactive memory maintenance action: ask to confirm, mark uncertain, defer, or forget.

Context:

Use the attached `EVIDENCE_NOTES.md` as the reviewed source map. Treat 2026 preprints as unverified/unfinished where appropriate. In particular, do not claim that this is the first Memory × Proactive Agent work: π-Bench, ProAct, Memento, ProAgentBench and related work already create substantial novelty pressure.

Return:

# Research Idea Review

## 1. One-Sentence Claim
"We propose X, using Y to solve Z, showing D on A/B/C."

## 2. Why This Problem Matters
What pain does it address? Why would readers care?

## 3. Novelty Diagnosis
Classify novelty as algorithm / data / benchmark / system / analysis / application. State what is truly new and what may just be repackaging.

## 4. Strongest Framing Options
Give 3 possible framings and their pros/cons.

## 5. Related-Work Pressure
What existing work would reviewers compare against? Separate exact supplied papers from additional unverified clusters.

## 6. Core Experiments
What experiments are required to support the claim? Identify the minimum viable paper and the full paper.

## 7. Killer Baselines and Ablations
What baseline or ablation could destroy the claim?

## 8. Reviewer Objections
Write likely reviewer objections and the evidence needed to answer each.

## 9. Paper Storyline
Propose title, abstract skeleton, and section outline.

## 10. Publishability Judgment
Choose: Strong Paper Direction / Workshop Direction / Needs Substantial Evidence / Not Paper-Worthy Yet.
Explain why.

## 11. Next 3 Actions
Give the next concrete actions for Codex/user.

Also answer these explicit decision questions:

1. Is constraint-state memory sufficiently distinct from LoCoMo-Plus, StructMemEval, PRISM, π-Bench, ProEvent, MemoryArena and LongMemEval-V2?
2. Which two or three benchmarks form the cleanest, least expensive evaluation suite?
3. Is a new benchmark required, or can controlled perturbations/extensions of existing benchmarks support the claim?
4. What is the cheapest experiment that could falsify the central hypothesis within one week?
5. What result threshold would make this a plausible ACL/EMNLP/ICLR main-conference submission?


# Codex Session Notes

## Metadata
- Bridge Thread ID: `memory-proactive-agent-2026-07-30`
- Codex Session ID: `memory-proactive-agent-2026-07-30-codex`
- Title: Memory x Proactive Agent research direction
- Created at: 2026-07-30T14:49:12+08:00
- Updated at: 2026-07-30T14:49:12+08:00
- History source: unavailable

## Goal

Map the task and benchmark landscape for agent memory and proactive agents, identify a defensible paper direction, and design a feasible experiment plan for 2-4 A100/A800 GPUs.

## GPT Pro Question

You are GPT Pro acting as a skeptical research advisor and top-conference reviewer.

I am not asking you to write code. I want you to evaluate and sharpen a research idea. Treat the attached evidence as partial evidence. Do not invent citations as facts; if you mention likely related-work clusters, mark them as clusters unless exact papers are supplied.

Idea / project:

Memory as Active Constraint State for Calibrated Proactive Agents.

The proposed system incrementally converts cross-session interactions into a provenance-aware, time-aware, versioned constraint state covering user goals, preferences, commitments, cancellations, permissions, failure modes, and unresolved dependencies. A proactive policy uses this state to choose among silence, ask, suggest, prepare, and execute under asymmetric benefit, interruption, false-positive, privacy, permission, and compute costs.

The intended empirical claim is that explicit online constraint lifecycle management plus a memory-conditioned intervention gate improves hidden-intent resolution and task completeness while reducing false alarms, stale-memory activations, cancellation errors, and permission violations.

Candidate evaluation:

- π-Bench for hidden intents, cross-session continuity, Proactivity and Completeness;
- LoCoMo-Plus for latent constraint consistency;
- ProEvent for event modification/cancellation and overaction;
- MemoryArena for memory-guided action;
- ProactiveBench for false-alarm and intervention calibration.

Potential method components:

1. Online constraint writer with no access to future evaluation questions.
2. State schema: subject, predicate, scope, valid interval, status, confidence, provenance, supersedes, allowed actions.
3. Conflict/update/expiry/deletion transitions.
4. Retrieval of active constraints plus evidence.
5. Benefit–burden gate and action-level permission policy.
6. Optional proactive memory maintenance action: ask to confirm, mark uncertain, defer, or forget.

Context:

Use the attached `EVIDENCE_NOTES.md` as the reviewed source map. Treat 2026 preprints as unverified/unfinished where appropriate. In particular, do not claim that this is the first Memory × Proactive Agent work: π-Bench, ProAct, Memento, ProAgentBench and related work already create substantial novelty pressure.

Return:

# Research Idea Review

## 1. One-Sentence Claim
"We propose X, using Y to solve Z, showing D on A/B/C."

## 2. Why This Problem Matters
What pain does it address? Why would readers care?

## 3. Novelty Diagnosis
Classify novelty as algorithm / data / benchmark / system / analysis / application. State what is truly new and what may just be repackaging.

## 4. Strongest Framing Options
Give 3 possible framings and their pros/cons.

## 5. Related-Work Pressure
What existing work would reviewers compare against? Separate exact supplied papers from additional unverified clusters.

## 6. Core Experiments
What experiments are required to support the claim? Identify the minimum viable paper and the full paper.

## 7. Killer Baselines and Ablations
What baseline or ablation could destroy the claim?

## 8. Reviewer Objections
Write likely reviewer objections and the evidence needed to answer each.

## 9. Paper Storyline
Propose title, abstract skeleton, and section outline.

## 10. Publishability Judgment
Choose: Strong Paper Direction / Workshop Direction / Needs Substantial Evidence / Not Paper-Worthy Yet.
Explain why.

## 11. Next 3 Actions
Give the next concrete actions for Codex/user.

Also answer these explicit decision questions:

1. Is constraint-state memory sufficiently distinct from LoCoMo-Plus, StructMemEval, PRISM, π-Bench, ProEvent, MemoryArena and LongMemEval-V2?
2. Which two or three benchmarks form the cleanest, least expensive evaluation suite?
3. Is a new benchmark required, or can controlled perturbations/extensions of existing benchmarks support the claim?
4. What is the cheapest experiment that could falsify the central hypothesis within one week?
5. What result threshold would make this a plausible ACL/EMNLP/ICLR main-conference submission?

## Detailed Session Summary

# Memory × Proactive Agent 研究证据与初步判断

更新日期：2026-07-30

## 1. 研究问题

这里的 `Memory` 指 LLM Agent 在多轮、跨会话、跨任务环境中对事实、状态、偏好、目标、约束、经验和失败模式的写入、更新、检索、遗忘与使用；`Proactive Agent` 指 Agent 在没有收到完整明确指令时，判断是否、何时、以何种方式介入，并通过提问、建议、工具调用或任务执行降低用户负担。

两者真正有研究价值的交叉点不是“给主动 Agent 加一个向量库”，而是：

> Agent 能否把历史交互转化为随时间演化、带来源和置信度的约束状态，并据此校准是否、何时以及如何介入。

## 2. 先区分几类经常被混在一起的任务

| 类型 | 核心问题 | 典型输入输出 | 是否真正测试 Agent Memory |
| --- | --- | --- | --- |
| 长上下文检索 | 上下文里有答案，模型能否找出来 | 静态长文本 → 答案 | 弱；没有持续写入、更新和复用 |
| 对话记忆 | 多次对话后能否回忆事实并做时间推理 | 历史会话 → QA/摘要 | 中；通常不要求行动 |
| 结构化记忆 | 能否主动形成 ledger、状态机、树等合适结构 | 增量事件 → 状态/答案 | 强；测试写入和维护 |
| 经验记忆 | 能否记住环境规则、操作流程和踩坑经验 | 旧轨迹 → 新任务行动 | 强；记忆直接影响行动 |
| 主动对话 | 能否规划目标并把对话带向目标 | 当前对话 → 提问/回复 | 通常弱；可不依赖长期记忆 |
| 主动介入 | 是否需要帮、何时帮、帮什么 | 活动流/历史 → 静默或介入 | 中到强；误报成本关键 |
| 跨会话主动 Agent | 历史偏好/约束能否帮助提前解决隐含需求 | 多任务工作区 → 行动/产物 | 最强交叉；同时测记忆和主动性 |

## 3. Memory 任务地图

### 3.1 事实、时间与知识更新

- **LoCoMo（ACL 2024）**：每段对话平均约 300 轮、9K tokens，最多 35 个 session；任务包括 QA、事件摘要和多模态对话生成。它奠定了长期对话记忆评测，但主要还是“历史中有什么”。  
  论文：https://arxiv.org/abs/2402.17753  
  代码：https://github.com/snap-research/locomo
- **LongMemEval（ICLR 2025）**：500 个问题，覆盖信息抽取、多 session 推理、时间推理、知识更新和拒答。它把 Memory 系统拆成 indexing、retrieval、reading 三阶段。  
  论文：https://arxiv.org/abs/2410.10813  
  代码：https://github.com/xiaowu0162/LongMemEval
- **MemoryAgentBench（ICLR 2026）**：用增量多轮交互测试准确检索、test-time learning、长程理解和选择性遗忘，明确区别于一次性把所有历史塞进上下文。  
  论文：https://arxiv.org/abs/2507.05257  
  代码：https://github.com/HUST-AI-HYZ/MemoryAgentBench
- **EverMemBench（2026 preprint）**：多方、多群组、超过百万 token 的交织对话，测试细粒度回忆、memory awareness 和用户画像理解，突出版本语义与多跳检索难题。  
  论文：https://arxiv.org/abs/2602.01313

### 3.2 隐式目标、偏好、价值与因果约束

- **LoCoMo-Plus（ACL 2026）**：从表面事实提升到 “cognitive memory”。过去信息以用户状态、目标、价值或因果约束的形式存在，后续触发语句与原始 cue 可能没有词义相似性；评测目标是行为是否满足约束，而不是是否复述事实。  
  论文：https://aclanthology.org/2026.acl-long.1150/  
  代码：https://github.com/xjtuleeyf/Locomo-Plus

这类任务最接近主动 Agent，因为 Agent 需要在用户没有重复说明时应用旧约束。

### 3.3 记忆结构的发现与维护

- **StructMemEval（2026 preprint）**：测试 Agent 是否知道应该把事件组织成交易账本、Todo/状态追踪器、树或计数结构。普通 RAG 表现差；给出结构提示后 Agent 能提升，但模型往往不能自己识别该用什么结构。  
  论文：https://arxiv.org/abs/2602.11243

它提示了一个重要空缺：不是每条 memory 都是平铺的“事实”。取消、覆盖、依赖、互斥和有效期需要显式状态结构。

### 3.4 从记忆到后续行动

- **MemoryArena（2026 preprint）**：用多 session 的 `Memory-Agent-Environment` 闭环，把早期行动与反馈变成经验，再要求 Agent 用这些经验完成后续任务。覆盖网页导航、偏好约束规划、渐进式信息搜索和序列化形式推理。论文指出，在 LoCoMo 上接近饱和的 Agent 在这里仍然困难。  
  论文：https://arxiv.org/abs/2602.16313  
  项目：https://memoryarena.github.io/
- **LongMemEval-V2（2026 work in progress）**：451 个手工问题，历史最多 500 条轨迹、115M tokens；测试静态状态、动态状态、工作流知识、环境坑点和前提意识。AgentRunbook-C 把轨迹存成文件并让 coding agent 搜索证据，平均 72.5%，高于最强 RAG 的 48.5%，但延迟高。  
  论文：https://arxiv.org/abs/2605.12493

这两个任务比单纯 LoCoMo 更适合研究“经验型同事”或长期 Coding/Research Agent。

### 3.5 多模态、流式和环境记忆

- **Memento（ICLR 2026）**：面向 5 分钟至 7 小时流式视频的全天候主动助手，使用 Dynamic Memory、Query-related Memory Selection 和 Step-Aware Memory Attention，Memento-54K/MementoBench 覆盖文本、物体、动作以及空间/时间任务。  
  论文：https://openreview.net/pdf?id=FtdbdoGbk3  
  会议信息：https://iclr.cc/virtual/2026/poster/10010551
- **M3-Agent / M3-Bench（ICLR 2026）**：第一视角长视频与视听输入上的 episodic/semantic memory 和跨模态推理。  
  项目与代码：https://github.com/bytedance-seed/m3-agent

多模态方向很强，但训练与数据成本显著高于文本/工具轨迹方向。

### 3.6 遗忘、隐私和预算

必须单独评测：

- 固定 memory budget 下保留什么；
- 用户纠正后旧版本是否被 supersede，而不是同时检索出来；
- 明确删除后能否不可恢复；
- 不同用户、项目、角色之间是否隔离；
- 离线构建 memory 时是否偷看了测试 query。

后一项尤其容易造成 evaluation leakage：如果系统根据当前测试问题决定写入或筛选过去 memory，就不再是部署时可实现的长期记忆。

## 4. Proactive Agent 任务地图

主动性至少包含四个相互独立的判断：

1. **Whether**：现在是否应当介入，还是保持静默；
2. **When**：介入时机是否过早、过晚或重复；
3. **What**：推断到了哪个潜在需求、目标或风险；
4. **How**：应该提问、建议、准备信息，还是在权限允许时直接执行。

只评最终回复质量，会掩盖大量“做了正确的事但打扰得不对”或“产物完成但没有提前发现隐含需求”的失败。

### 4.1 需求检测与介入分类

- **Proactive Agent / ProactiveBench（ICLR 2025）**：从 coding、writing、daily life 活动中构建 6,790 个事件，预测一个建议是否会被接受；公开数据生成、训练和评测代码。原始基线的 false alarm 很高，说明主动 Agent 的首要难题不是“总能想出建议”，而是“知道什么时候不要说”。  
  论文：https://arxiv.org/abs/2410.12361  
  代码：https://github.com/thunlp/ProactiveAgent
- **PRISM（2026 preprint）**：将主动介入形式化为非对称成本下的 selective intervention；只有当校准后的接受概率超过由漏帮与误报成本推导出的阈值时才介入。论文报告在 ProactiveBench 上 false alarm 降低 22.78%。  
  论文：https://arxiv.org/abs/2602.01532  
  项目：https://prism-festinalente.github.io/

因此，“加一个是否主动的分类器”本身已经不新；需要让 gate 与长期记忆状态、过期/冲突和行为成本发生实质联系。

### 4.2 目标规划与对话引导

- **ProactiveEval（ACL 2026）**：将主动对话拆成 target planning 与 dialogue guidance，共 328 个环境、6 类领域，包括推荐、说服、澄清、长期 follow-up、系统操作和眼镜助手。  
  论文：https://aclanthology.org/2026.acl-long.1906/  
  预印本：https://arxiv.org/abs/2508.20973
- **Proactive dialogue（Findings of EMNLP 2023）**：较早地将主动对话概括为澄清、目标引导和不合作/拒绝三类。  
  论文：https://aclanthology.org/2023.findings-emnlp.711/

### 4.3 真实工作流中的 timing 与 content

- **ProAgentBench（2026 preprint）**：28,000+ events、500+ 小时真实工作 session；将任务分成介入时机预测和帮助内容生成。论文报告长历史与长期 memory 会提高准确率，真实数据训练优于合成数据。  
  论文：https://arxiv.org/abs/2602.04482  
  数据：https://huggingface.co/datasets/qv9n2xk7m1z8pt4/ProAgentBench

它更贴近桌面 Coding/Research Agent，但原始活动数据涉及隐私，扩数据会比文本 benchmark 困难。

### 4.4 跨 session 的隐含需求

- **π-Bench（2026 preprint）**：100 个多轮任务、5 个职业 persona，工作区在 session 间持续存在；包含隐含 intent、任务依赖和跨 session 连续性。主要指标是 Proactivity（是否提前推断/澄清潜在需求）与 Completeness（最终产物是否完成）。  
  论文：https://arxiv.org/abs/2605.14678  
  代码：https://github.com/Simplified-Reasoning/Pi-Bench

这是当前 Memory × Proactive Agent 最直接的公开基准。因此不能声称“首次把长期记忆和主动性结合”；可做的创新必须落在显式 memory lifecycle、版本化约束、介入成本或可解释性上。

### 4.5 事件维护、取消与连续提醒

- **ProEvent（2026-07 preprint）**：从并行 IM 对话中主动维护用户日程，评测响应时机、单步正确性和多步正确性。当前模型常常 overact，并难以正确处理事件取消；论文报告 GPT-5.1 也只在 26.7% 场景中正确反应。  
  论文：https://arxiv.org/abs/2607.17701

事件取消不是普通检索问题，而是典型的 memory state transition：`planned → changed → cancelled`。这与版本化约束记忆高度一致。

### 4.6 多人协作中的适时介入

- **ProACT（2026-07 preprint）**：检测多人协作中的分歧、目标模糊、遗漏约束、讨论循环和参与失衡，决定静默或介入，再路由到不同协作技能；含 3,244 个 turn-level 样例。  
  论文：https://arxiv.org/abs/2607.03730

这扩展出 team memory、speaker attribution 和 common ground，但也增加标注及多人状态建模成本。

### 4.7 空闲时预取信息

- **Anticipate and Learn / ProAct（2026 preprint）**：利用会话间 idle-time compute 和持久 memory 预测后续需求、提前补齐知识；ProActEval 含 40 个领域、200 个场景。论文用所需轮次、用户 effort 和幻觉率评测。  
  论文：https://arxiv.org/abs/2605.25971

“后台先做研究、用户下一次问时已准备好”与 auto-research 使用场景直接相关，但要把推测性预取的算力浪费和隐私风险计入成本。

## 5. 当前真正有价值的交叉空缺

### A. Versioned Constraint Memory（优先级：最高）

把历史中的偏好、目标、承诺、否定、权限和失败模式编译成可执行约束，而不是无结构文本片段：

```text
subject
predicate / constraint
scope
valid_from / valid_until
status: active | superseded | cancelled | uncertain
confidence
provenance
supersedes
allowed_actions
```

主动 policy 在每个时刻选择：

```text
silence | ask | suggest | prepare | execute
```

关键不是检索到多少，而是当前有效约束是否被正确应用、已取消约束是否不再触发、冲突时是否澄清。

### B. Memory-conditioned Benefit–Burden Gate（优先级：高）

估计每次介入的预期效用：

```text
E[task benefit]
- λ1 * interruption cost
- λ2 * false-positive cost
- λ3 * privacy/permission risk
- λ4 * compute cost
```

新意必须来自 memory 对 gate 的影响，例如：

- 用户过去多次拒绝某类提醒，阈值应上升；
- 当前约束来自低置信度推断，只能 ask，不能 execute；
- 旧偏好已过期或被更正，不能继续主动触发；
- 高风险操作即使预期有用，也必须请求确认。

### C. Proactive Memory Maintenance（优先级：高）

Agent 的主动行为不只为完成当前任务，也可以改善未来 memory：

- 发现冲突时主动确认哪个版本有效；
- 对长期承诺设置检查点；
- 识别重要但缺失的 scope/expiry；
- 对可疑 inferred preference 请求确认；
- 在预算压力下询问哪些记录可删。

这把 memory write policy 与 proactive policy 合并为序贯决策问题。

### D. Decision-centric / Failure-centric Memory（优先级：高）

经验型 Agent 不应存所有对话，而应优先存：

- 关键决策及理由；
- 被用户纠正的假设；
- 失败命令、环境坑点与修复；
- 尚未完成的承诺和依赖；
- 权限边界与不可自动执行事项。

适合 LongMemEval-V2、MemoryArena 和 Coding/Research Agent。

### E. Multimodal Always-on Assistant（优先级：中，成本高）

融合视觉、窗口活动、语音与工具轨迹，判断什么时候介入。Memento 和 ProAgentBench 已经占据明显先发位置；如果没有新的真实数据或独特场景，单纯改 memory module 难度较大。

## 6. 最推荐的论文命题

工作标题：

> **Memory as Active Constraint State for Calibrated Proactive Agents**

一句话主张：

> 维护带来源、时间、版本、置信度和权限的约束状态，并用成本敏感的介入 gate 决定静默、澄清、建议或执行，可以在跨会话任务中提高隐含需求解决率和最终任务完成度，同时减少无效打扰、过期偏好触发和取消状态错误。

### 为什么它比“Memory + Proactivity”更具体

- `π-Bench` 已证明历史交互有助于潜在 intent，不能再把结合本身当 novelty；
- PRISM 已有成本敏感 gate，不能只做一个二分类器；
- LoCoMo-Plus 已有 latent constraint，但没有完整主动行动闭环；
- ProEvent 暴露取消/状态演化问题，但没有通用的约束 memory lifecycle；
- MemoryArena/LME-V2 强调经验到行动，但没有把打扰成本作为核心。

可发表空间在于：**版本化约束状态 + 可校准介入策略 + 跨 benchmark 的统一评测协议**。

## 7. 核心实验设计

### RQ1：结构化、版本化约束是否优于全文历史和普通 RAG？

评测：

- `π-Bench`：PROC、COMP；
- `LoCoMo-Plus`：constraint consistency；
- `ProEvent`：取消、修改、重复提醒正确率；
- `MemoryArena` preference/planning 子集：后续行动成功率。

基线：

1. 无 memory 的 reactive agent；
2. 完整历史/长上下文；
3. BM25；
4. embedding RAG；
5. 现成 memory system（至少 Mem0、A-Mem 类）；
6. oracle relevant history；
7. 只加 prompt 的结构化 memory；
8. 本方法去掉 version/provenance/expiry 的消融。

### RQ2：memory-conditioned gate 能否降低 false alarm？

评测：

- ProactiveBench 的 precision、recall、F1、false alarm；
- π-Bench 中不必要澄清/建议次数；
- ProEvent 的 overaction；
- 成本加权 utility 与 calibration error。

基线：

- always act；
- reactive only；
- 固定阈值；
- PRISM 类 cost-sensitive gate；
- oracle active constraint；
- 本方法无用户反馈历史。

### RQ3：Agent 能否处理 memory 的时间演化？

构造受控扰动：

- preference update；
- event cancel；
- goal supersede；
- permission revoke；
- temporary constraint expiry；
- 多来源冲突；
- 用户明确删除。

指标：

- stale-memory activation rate；
- cancellation consistency；
- update latency；
- conflict clarification precision；
- deletion compliance。

### RQ4：主动维护 memory 是否值得？

允许 Agent 在关键点执行 `ask-to-confirm`、`mark-uncertain`、`defer`、`forget`。

比较：

- task success；
- 用户额外轮次；
- 后续 session 错误率；
- memory size/token；
- 每次有效干预带来的收益。

## 8. 审稿人会攻击的点

1. **“只是 RAG 加字段”**：必须证明版本、状态转换、权限和 provenance 进入 policy，而不是仅用于 prompt 展示。
2. **“π-Bench 已经做了 memory + proactivity”**：不可宣称首次交叉；应明确增量是 memory lifecycle 和 benefit–burden calibration。
3. **“LLM judge 不可靠”**：尽量使用 executable checklist、environment state、事件状态和人工小样本校准；主指标不能全靠开放式 judge。
4. **“query-aware leakage”**：历史写入阶段不得看到未来测试问题；检索触发可以看当前 observation，但 memory construction 必须 online。
5. **“full-history 大模型就够了”**：必须报告同模型、同 token/延迟预算下的 full-context baseline。
6. **“主动建议越多分越高”**：必须对 false alarm、重复打扰、权限越界和错误执行施加显式成本。
7. **“数据是合成的”**：组合公开 benchmark 后，最好增加一小套真实 coding/research trajectory 或用户研究验证外部有效性。
8. **“只在一个 benchmark 上调参”**：至少跨一个 memory benchmark、一个 proactive benchmark、一个 agentic/action benchmark。

## 9. 算力与执行可行性

### 第一阶段：不训练，先验证命题

- 用 API/开源推理复现小规模 `π-Bench`、ProEvent、LoCoMo-Plus；
- 实现 memory schema、online update、retrieval 和 rule/calibrated gate；
- 主要成本是 agent rollout 与 judge API，不一定需要本地 GPU；
- 如果本地部署 7B/14B，`1–2 × A100/A800 80G` 足够做调试和单次评测。

### 第二阶段：训练 gate 或 memory writer

- 7B/8B LoRA/SFT：`2 × 80G` 是实用起点；
- 14B LoRA 或较长序列训练：建议 `2–4 × 80G`；
- 32B LoRA、长序列 RL 或大量并行 rollout：建议 `4–8 × 80G`；
- 全参数训练不是验证该方向的必要条件。

### 第三阶段：多模态

- ProAgentBench 的截图/VLM 或 Memento 长视频会显著放大存储、预处理和训练成本；
- 建议先用文本/工具轨迹拿到清晰结论，再决定是否扩到 `4–8 × 80G` 的多模态实验。

### L20/H20 是否可用

- `8 × L20` 可做 7B/14B LoRA、并行 rollout 和不少 VLM 实验，但单卡显存通常低于 A100/A800 80G，需要 ZeRO/FSDP、gradient checkpointing 和更小 micro-batch；
- `H20` 更偏高显存、推理与受限算力场景，具体是否优于 A100/A800 取决于集群卡型规格、互联和训练栈；
- 对本课题的第一阶段，稳定可复用的 `2–4 × 80G A100/A800` 比峰值卡数更重要，因为主要瓶颈是快速交互、反复 rollout 与跨 benchmark 调试。

## 10. 推荐推进顺序

1. 先跑 `π-Bench` 的 researcher persona 单次 trial，确认环境、成本和输出结构；
2. 跑 LoCoMo-Plus 小样本，验证 constraint extraction；
3. 做一个最小 online versioned memory，不训练；
4. 加 ProEvent 的取消/修改测试，确认结构确实解决 state transition；
5. 再加入 cost-sensitive gate，测 false alarm 与 calibration；
6. 只有上述结果成立后，才训练 7B/8B memory writer 或 intervention policy；
7. 最后扩展 MemoryArena/LME-V2 或真实 coding/research trajectory。

## 11. 当前结论

- **最值得做的任务不是普通事实记忆，而是会改变未来行动的“约束/状态/经验记忆”。**
- **最值得做的主动性不是让 Agent 多说，而是让它准确选择静默、澄清、建议、准备和执行。**
- **两者交叉已经有 π-Bench、ProAct 和 Memento 等工作，不能用宽泛的“Memory + Proactive”作为 novelty。**
- **最强且可控的切入点是：版本化约束记忆 + 成本敏感介入 + 取消/过期/冲突/权限评测。**
- **先用文本和工具轨迹做，2–4 张 80G 卡已足以推进主要实验；多模态可作为后续扩展。**

## Recent Raw Conversation

_Raw Codex turns were not included. The detailed summary is the complete Codex-side context for this snapshot._

## Evidence Rules

- Treat the detailed summary as primary context.
- Use raw turns only for nuance; they may be incomplete.
- Do not infer repository facts that are absent from the attached evidence.
